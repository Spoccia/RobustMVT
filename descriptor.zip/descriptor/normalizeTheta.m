function angle_normalized = normalizeTheta(angle)

    angle_normalized = wrapTo2Pi(angle);
end